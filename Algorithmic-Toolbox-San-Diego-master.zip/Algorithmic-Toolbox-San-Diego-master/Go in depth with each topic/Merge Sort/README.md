<img src="https://www.geeksforgeeks.org/wp-content/uploads/Merge-Sort-Tutorial.png" align="center">
