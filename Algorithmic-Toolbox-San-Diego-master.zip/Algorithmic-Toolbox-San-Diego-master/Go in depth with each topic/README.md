## ✔ This a List of The Topics I Have Learned From Algoritmic Toolbox Course  :
-----------------------------------------------------------------------------------------------------------------------
### Week-1
#### Topics :
		1- Just an introduction To Algorithms [✔]
		
#### Problems:
			 1-sum of two digits [✔]
			 2-maximum pairwise product [✔]
-----------------------------------------------------------------------------------------------------------------------
###	 Week-2
#### Topics :
		1- Why We Study Algorithms [✔]
		2- Fibonacci Numbers [✔]
		3- Greatest Common Divisor [✔] 
		4- Least Common Multiple [✔]
		5- Big O Notation [✔]	
		
#### Problems:
			1-fibonacci number [✔]
			2-last digit of fibonacci number [✔]
			3-greatest_common_divisor [✔]
			4-least_common_multiple [✔]
			5-fibonacci_number_again [✔] 
			6-last_digit_of_the_sum_of_fibonacci_numbers [✔]
			7-last_digit_of_the_sum_of_fibonacci_numbers_again ()
	 		8-last_digit_of_the_sum_of_squares_of_fibonacci_numbers [✔]

-----------------------------------------------------------------------------------------------------------------------
### Week-3
#### Topics :
		1- Introduction To Greedy Algoritm [✔] 
		2- Grouping Children [✔] 
		3- Franctional Knapsack Problem [✔] 
		4- 0/1 Knapsack Problem [✔] 

#### Problems:
			1-money_change [✔] 
			2-maximum_value_of_the_loot [✔] 
			3-maximum_advertisement_revenue [✔] 
			4-collecting_signatures [✔] 
			5-maximum_number_of_prizes [✔] 
			6-maximum_salary [✔] 
----------------------------------------------------------------------------------------------------------------------
###	Week-4
#### Topics :

		1- Linear Search , Binary Search [✔] 
		2- Polynomial Multiplication [✔]
		3- Master Theorem ()
		4- Selction Sort [✔]
		5- Merge Sort [✔]
		6- counting Sort ()
		7- Quick Sort ()

#### Problems:
			1-binary_search ()
			2-majority_element ()
			3-improving_quicksort ()
			4-number_of_inversions ()
			5-organizing_a_lottery ()
			6-closest_points ()


----------------------------------------------------------------------------------------------------------------------
### Week-5
#### Topics :
		1- Change Problem ()
		2- Largest Common Subsequance ()
		3- The Alignment Game ()
		4- Edit Distance()
		5- Merge Sort ()

#### Problems:
			1-money_change_again ()
			2-primitive_calculator()
			3-edit_distance ()
			4-longest_common_subsequence_of_two_sequences ()
			5-longest_common_subsequence_of_three_sequences()

----------------------------------------------------------------------------------------------------------------------
### Week-6
#### Topics :
		1- 0_1 KnapSack [✔]
		2- KnapSack With Repetitions ()
		3- KnapSack Without Repetitions ()
		4-Placing Parenthesses ()	
#### Problems:
			1-maximum_amount_of_gold ()			
			2-partitioning_souvenirs ()
			3-maximum_value_of_an_arithmetic_expression ()
